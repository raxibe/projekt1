package com.example.myapplication

data class WeatherResponse(
    val location: Location,
    val current: Current
)